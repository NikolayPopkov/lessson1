import UIKit

// Решить квадратное уравнение

let a = 2.0, b = 5.0, c = 2.0
let dis = b * b - 4 * a * c
var x1, x2: Double
if dis > 0 {
    x1 = (b + sqrt (dis)) / (2 * a)
    x2 = (b - sqrt (dis)) / (2 * a)
    print (x1,x2)
} else if dis == 0 {
    x1 = -b / (2*a)
    print(x1)
} else {
    print("Корней нет")
}

// Даны катеты прямоугольного треугольника. Найти площадь, периметр и гипотенузу треугольника

let kat1 = 4.0, kat2 = 6.0
let area = (kat1 * kat2) / 2
let gip = sqrt((kat1 * kat1) + (kat2 * kat2))
let per = kat1 + kat2 + gip
print("Площадь треуголника =", area)
print("Гипотенуза треуголника =", gip)
print("Периметр треуголника =", per)

// Пользователь вводит сумму вклада в банк и годовой процент. Найти сумму вклада через 5 лет
var dep, perc, years: Double
dep = 55000.0
perc = 10.0
years = 5.0
var summ = dep + dep * 10 * (years * 365) / 365 / 100
print("Сумма по окончании вклада", summ)
